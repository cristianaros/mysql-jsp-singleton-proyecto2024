package Funciones;

import com.mysql.conexion.Conexion;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import java.io.IOException;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/AgregarProducto")
@MultipartConfig // Necesario para manejar la subida de archivos
public class AgregarProducto extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtener parámetros del formulario
        String nombreProducto = request.getParameter("nombreProducto");
        String descripcion = request.getParameter("descripcion");
        double precio = Double.parseDouble(request.getParameter("precio"));
        int stock = Integer.parseInt(request.getParameter("stock"));

        // Manejar la imagen subida
        Part imagen = request.getPart("imagen");
        String nombreImagen = Paths.get(imagen.getSubmittedFileName()).getFileName().toString(); // Obtener el nombre del archivo
        String rutaImagen = getServletContext().getRealPath("/") + "img/" + nombreImagen; // Guardar la imagen en la carpeta "img" dentro del proyecto
        imagen.write(rutaImagen); // Guardar la imagen en el servidor

        try (Connection con = Conexion.getConnection()) {
            // Consulta SQL para insertar producto con imagen
            String query = "INSERT INTO producto (NombreProducto, Descripcion, Precio, Stock, Imagen) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement ps = con.prepareStatement(query)) {
                ps.setString(1, nombreProducto);
                ps.setString(2, descripcion);
                ps.setDouble(3, precio);
                ps.setInt(4, stock);
                ps.setString(5, "img/" + nombreImagen); // Ruta relativa de la imagen

                ps.executeUpdate();
            }
        } catch (SQLException e) {
            throw new ServletException("Error al agregar el producto", e);
        }

        // Redirigir a la página de gestión de productos después de agregar
        response.sendRedirect("gestionProductos.jsp");
    }
}
