package Funciones;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.mysql.conexion.Conexion;

public class Login {
    public boolean autenticarUsuario(String email, String contrasena) {
        String query = "SELECT e.IdEmpleado, e.NombreEmpleado, r.NombreRol " +
                       "FROM empleado e " +
                       "JOIN usuarios_roles ur ON e.IdEmpleado = ur.IdUsuario " +
                       "JOIN roles r ON ur.IdRol = r.IdRol " +
                       "WHERE e.Email = ? AND e.Contrasena = ?";
        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(query)) {
            ps.setString(1, email);
            ps.setString(2, contrasena);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                // Usuario autenticado correctamente
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}