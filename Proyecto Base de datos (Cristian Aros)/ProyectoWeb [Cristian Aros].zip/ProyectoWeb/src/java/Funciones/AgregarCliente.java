package Funciones;

import com.mysql.conexion.Conexion;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/AgregarUsuario")
public class AgregarCliente extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String rut = request.getParameter("rut");
        String nombres = request.getParameter("nombres");
        String direccion = request.getParameter("direccion");
        String region = request.getParameter("region");

        try (Connection con = Conexion.getConnection()) {
            String query = "INSERT INTO cliente (RUT, Nombres, Direccion, Region) VALUES (?, ?, ?, ?)";
            try (PreparedStatement ps = con.prepareStatement(query)) {
                ps.setString(1, rut);
                ps.setString(2, nombres);
                ps.setString(3, direccion);
                ps.setString(4, region);

                ps.executeUpdate();
            }
        } catch (SQLException e) {
            throw new ServletException("Error al agregar el usuario", e);
        }

        response.sendRedirect("gestionUsuarios.jsp"); // Redirige a la gestión de usuarios
    }
}