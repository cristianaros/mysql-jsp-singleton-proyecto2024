package Funciones;

import com.mysql.conexion.Conexion;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/EliminarCliente")
public class EliminarCliente extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String idClienteStr = request.getParameter("id");

        if (idClienteStr == null || idClienteStr.isEmpty()) {
            request.setAttribute("mensaje", "Error: ID del cliente no proporcionado.");
            request.getRequestDispatcher("gestionClientes.jsp").forward(request, response);
            return;
        }

        int idCliente;
        try {
            idCliente = Integer.parseInt(idClienteStr);
        } catch (NumberFormatException e) {
            request.setAttribute("mensaje", "Error: ID del cliente inválido.");
            request.getRequestDispatcher("gestionClientes.jsp").forward(request, response);
            return;
        }

        try (Connection con = Conexion.getConnection()) {
            // Intentar eliminar el cliente
            String query = "DELETE FROM cliente WHERE IdCliente = ?";
            try (PreparedStatement ps = con.prepareStatement(query)) {
                ps.setInt(1, idCliente);
                int rowsDeleted = ps.executeUpdate();

                if (rowsDeleted > 0) {
                    request.setAttribute("mensaje", "Cliente eliminado exitosamente.");
                } else {
                    request.setAttribute("mensaje", "Error: No se encontró el cliente con el ID proporcionado.");
                }
            }
        } catch (SQLException e) {
            if (e.getSQLState().startsWith("23")) { // Error de clave externa
                request.setAttribute("mensaje", "Error: No se puede eliminar el cliente debido a dependencias en otras tablas.");
            } else {
                request.setAttribute("mensaje", "Error al eliminar el cliente: " + e.getMessage());
            }
        }

        // Redirigir a gestionClientes.jsp con el mensaje
        request.getRequestDispatcher("gestionUsuarios.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response); // Reutiliza el método doGet para manejar POST
    }
}
