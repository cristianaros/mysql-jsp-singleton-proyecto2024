package Funciones;

import com.mysql.conexion.Conexion;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/ModificarCliente")
public class ModificarCliente extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtener el ID del cliente desde el parámetro de la solicitud
        String idCliente = request.getParameter("id");

        if (idCliente == null || idCliente.isEmpty()) {
            // Manejo de error si no se pasa el ID del cliente
            request.setAttribute("mensaje", "Error: ID del cliente no proporcionado.");
            request.getRequestDispatcher("resultado.jsp").forward(request, response);
            return;
        }

        try (Connection conn = Conexion.getConnection()) {
            // Consulta para obtener los datos del cliente
            String query = "SELECT IdCliente, RUT, Nombres, Direccion, Region FROM cliente WHERE IdCliente = ?";
            try (PreparedStatement ps = conn.prepareStatement(query)) {
                ps.setInt(1, Integer.parseInt(idCliente));

                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        // Establecer los datos del cliente como atributos de la solicitud
                        request.setAttribute("idCliente", rs.getString("IdCliente"));
                        request.setAttribute("rutCliente", rs.getString("RUT"));
                        request.setAttribute("nombreCliente", rs.getString("Nombres"));
                        request.setAttribute("direccionCliente", rs.getString("Direccion"));
                        request.setAttribute("regionCliente", rs.getString("Region"));
                    } else {
                        // Si no se encuentra el cliente, enviar mensaje de error
                        request.setAttribute("mensaje", "Error: No se encontró ningún cliente con el ID proporcionado.");
                        request.getRequestDispatcher("resultado.jsp").forward(request, response);
                        return;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("mensaje", "Error al conectar con la base de datos: " + e.getMessage());
            request.getRequestDispatcher("resultado.jsp").forward(request, response);
            return;
        }

        // Redirigir al JSP para editar
        request.getRequestDispatcher("editarCliente.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtener los datos actualizados del formulario
        String idCliente = request.getParameter("idCliente");
        String rutCliente = request.getParameter("rutCliente");
        String nombreCliente = request.getParameter("nombreCliente");
        String direccionCliente = request.getParameter("direccionCliente");
        String regionCliente = request.getParameter("regionCliente");

        if (idCliente == null || idCliente.isEmpty() ||
            rutCliente == null || rutCliente.isEmpty() ||
            nombreCliente == null || nombreCliente.isEmpty() ||
            direccionCliente == null || direccionCliente.isEmpty() ||
            regionCliente == null || regionCliente.isEmpty()) {
            // Validar que los campos requeridos no estén vacíos
            request.setAttribute("mensaje", "Error: Todos los campos son obligatorios.");
            request.getRequestDispatcher("resultado.jsp").forward(request, response);
            return;
        }

        boolean actualizacionExitosa = false;

        try (Connection conn = Conexion.getConnection()) {
            // Consulta para actualizar los datos del cliente
            String updateQuery = "UPDATE cliente SET RUT = ?, Nombres = ?, Direccion = ?, Region = ? WHERE IdCliente = ?";
            try (PreparedStatement ps = conn.prepareStatement(updateQuery)) {
                ps.setString(1, rutCliente);
                ps.setString(2, nombreCliente);
                ps.setString(3, direccionCliente);
                ps.setString(4, regionCliente);
                ps.setInt(5, Integer.parseInt(idCliente));

                int rowsUpdated = ps.executeUpdate();
                actualizacionExitosa = rowsUpdated > 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("mensaje", "Error al actualizar los datos del cliente en la base de datos: " + e.getMessage());
            request.getRequestDispatcher("resultado.jsp").forward(request, response);
            return;
        }

        // Redirigir según el resultado de la operación
        if (actualizacionExitosa) {
            request.setAttribute("mensaje", "El cliente fue actualizado exitosamente.");
        } else {
            request.setAttribute("mensaje", "Hubo un error al actualizar el cliente. Inténtalo nuevamente.");
        }
        request.getRequestDispatcher("resultado.jsp").forward(request, response);
    }
}
