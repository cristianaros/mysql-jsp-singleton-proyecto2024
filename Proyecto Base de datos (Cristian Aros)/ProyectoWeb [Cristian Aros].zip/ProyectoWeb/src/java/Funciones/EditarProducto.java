package Funciones;

import com.mysql.conexion.Conexion;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet("/EditarProducto")
public class EditarProducto extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtener parámetros del formulario
        String idProducto = request.getParameter("idProducto");
        String nombreProducto = request.getParameter("nombreProducto");
        String descripcionProducto = request.getParameter("descripcionProducto");
        String precioProducto = request.getParameter("precioProducto");
        String stockProducto = request.getParameter("stockProducto");

        if (idProducto == null || idProducto.isEmpty() ||
            nombreProducto == null || nombreProducto.isEmpty() ||
            descripcionProducto == null || descripcionProducto.isEmpty() ||
            precioProducto == null || precioProducto.isEmpty() ||
            stockProducto == null || stockProducto.isEmpty()) {

            request.setAttribute("mensaje", "Error: Todos los campos son obligatorios.");
            request.getRequestDispatcher("gestionProductos.jsp").forward(request, response);
            return;
        }

        boolean actualizacionExitosa = false;

        try (Connection con = Conexion.getConnection()) {
            String query = "UPDATE producto SET NombreProducto = ?, Descripcion = ?, Precio = ?, Stock = ? WHERE idProducto = ?";
            try (PreparedStatement ps = con.prepareStatement(query)) {
                ps.setString(1, nombreProducto);
                ps.setString(2, descripcionProducto);
                ps.setDouble(3, Double.parseDouble(precioProducto));
                ps.setInt(4, Integer.parseInt(stockProducto));
                ps.setInt(5, Integer.parseInt(idProducto));

                actualizacionExitosa = ps.executeUpdate() > 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("mensaje", "Error al actualizar los datos del producto.");
            request.getRequestDispatcher("gestionProductos.jsp").forward(request, response);
            return;
        }

        // Redirigir según el resultado
        if (actualizacionExitosa) {
            response.sendRedirect("gestionProductos.jsp");
        } else {
            request.setAttribute("mensaje", "No se pudo actualizar el producto.");
            request.getRequestDispatcher("gestionProductos.jsp").forward(request, response);
        }
    }
}

