package Funciones;

import com.mysql.conexion.Conexion;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/ModificarEmpleado")
public class ModificarEmpleado extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtener el ID del empleado desde el parámetro de la solicitud
        String idEmpleado = request.getParameter("id");

        if (idEmpleado == null || idEmpleado.isEmpty()) {
            // Manejo de error si no se pasa el ID del empleado
            request.setAttribute("mensaje", "Error: ID de empleado no proporcionado.");
            request.getRequestDispatcher("resultado.jsp").forward(request, response);
            return;
        }

        try (Connection conn = Conexion.getConnection()) {
            // Consulta para obtener los datos del empleado
            String query = "SELECT IdEmpleado, NombreEmpleado, Email, roles FROM empleado WHERE IdEmpleado = ?";
            try (PreparedStatement ps = conn.prepareStatement(query)) {
                ps.setInt(1, Integer.parseInt(idEmpleado));

                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        // Establecer los datos del empleado como atributos de la solicitud
                        request.setAttribute("idEmpleado", rs.getInt("IdEmpleado"));
                        request.setAttribute("nombreEmpleado", rs.getString("NombreEmpleado"));
                        request.setAttribute("emailEmpleado", rs.getString("Email"));
                        request.setAttribute("rolEmpleado", rs.getString("roles"));
                    } else {
                        // Si no se encuentra el empleado, enviar mensaje de error
                        request.setAttribute("mensaje", "Error: No se encontró ningún empleado con el ID proporcionado.");
                        request.getRequestDispatcher("resultado.jsp").forward(request, response);
                        return;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("mensaje", "Error al conectar con la base de datos.");
            request.getRequestDispatcher("resultado.jsp").forward(request, response);
            return;
        }

        // Redirigir al JSP para editar
        request.getRequestDispatcher("editarEmpleado.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtener los datos actualizados del formulario
        String idEmpleado = request.getParameter("idEmpleado");
        String nombreEmpleado = request.getParameter("nombreEmpleado");
        String emailEmpleado = request.getParameter("emailEmpleado");
        String rolEmpleado = request.getParameter("rolEmpleado");

        if (idEmpleado == null || idEmpleado.isEmpty() || 
            nombreEmpleado == null || nombreEmpleado.isEmpty() || 
            emailEmpleado == null || emailEmpleado.isEmpty() || 
            rolEmpleado == null || rolEmpleado.isEmpty()) {
            // Validar que los campos requeridos no estén vacíos
            request.setAttribute("mensaje", "Error: Todos los campos son obligatorios.");
            request.getRequestDispatcher("resultado.jsp").forward(request, response);
            return;
        }

        boolean actualizacionExitosa = false;

        try (Connection conn = Conexion.getConnection()) {
            // Consulta para actualizar los datos del empleado
            String updateQuery = "UPDATE empleado SET NombreEmpleado = ?, Email = ?, roles = ? WHERE IdEmpleado = ?";
            try (PreparedStatement ps = conn.prepareStatement(updateQuery)) {
                ps.setString(1, nombreEmpleado);
                ps.setString(2, emailEmpleado);
                ps.setString(3, rolEmpleado);
                ps.setInt(4, Integer.parseInt(idEmpleado));
                actualizacionExitosa = ps.executeUpdate() > 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("mensaje", "Error al actualizar los datos del empleado en la base de datos.");
            request.getRequestDispatcher("resultado.jsp").forward(request, response);
            return;
        }

        // Redirigir según el resultado de la operación
        if (actualizacionExitosa) {
            request.setAttribute("mensaje", "El empleado fue actualizado exitosamente.");
        } else {
            request.setAttribute("mensaje", "Hubo un error al actualizar el empleado. Inténtalo nuevamente.");
        }
        request.getRequestDispatcher("resultado.jsp").forward(request, response);
    }
}
