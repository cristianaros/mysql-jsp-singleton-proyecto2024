package Funciones;

import com.mysql.conexion.Conexion;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/EliminarEmpleado")
public class EliminarEmpleado extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String idEmpleadoStr = request.getParameter("id");

        if (idEmpleadoStr == null || idEmpleadoStr.isEmpty()) {
            request.setAttribute("mensaje", "Error: ID del empleado no proporcionado.");
            request.getRequestDispatcher("gestionUsuarios.jsp").forward(request, response);
            return;
        }

        int idEmpleado;
        try {
            idEmpleado = Integer.parseInt(idEmpleadoStr);
        } catch (NumberFormatException e) {
            request.setAttribute("mensaje", "Error: ID del empleado inválido.");
            request.getRequestDispatcher("gestionUsuarios.jsp").forward(request, response);
            return;
        }

        try (Connection con = Conexion.getConnection()) {
            // Intentar eliminar el empleado
            String query = "DELETE FROM empleado WHERE IdEmpleado = ?";
            try (PreparedStatement ps = con.prepareStatement(query)) {
                ps.setInt(1, idEmpleado);
                int rowsDeleted = ps.executeUpdate();

                if (rowsDeleted > 0) {
                    request.setAttribute("mensaje", "Empleado eliminado exitosamente.");
                } else {
                    request.setAttribute("mensaje", "Error: No se encontró el empleado con el ID proporcionado.");
                }
            }
        } catch (SQLException e) {
            if (e.getSQLState().startsWith("23")) { // Error de clave externa
                request.setAttribute("mensaje", "Error: No se puede eliminar el empleado debido a dependencias en otras tablas.");
            } else {
                request.setAttribute("mensaje", "Error al eliminar el empleado: " + e.getMessage());
            }
        }

        // Redirigir a gestionUsuarios.jsp con el mensaje
        request.getRequestDispatcher("gestionUsuarios.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response); // Reutiliza el método doGet para manejar POST
    }
}