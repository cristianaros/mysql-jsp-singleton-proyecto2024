package Funciones;

import com.mysql.conexion.Conexion;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/EliminarProducto")
public class eliminarProducto extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Obtener el ID del producto desde el formulario
        String idProducto = request.getParameter("idProducto");

        if (idProducto == null || idProducto.isEmpty()) {
            response.sendRedirect("gestionProductos.jsp?mensaje=Error: ID del producto no proporcionado.");
            return;
        }

        try (Connection con = Conexion.getConnection()) {
            // Eliminar el producto
            String query = "DELETE FROM producto WHERE IdProducto = ?";
            try (PreparedStatement ps = con.prepareStatement(query)) {
                ps.setInt(1, Integer.parseInt(idProducto));
                int rowsDeleted = ps.executeUpdate();

                if (rowsDeleted > 0) {
                    response.sendRedirect("gestionProductos.jsp?mensaje=Producto eliminado correctamente.");
                } else {
                    response.sendRedirect("gestionProductos.jsp?mensaje=Error al eliminar el producto.");
                }
            }
        } catch (SQLException e) {
            throw new ServletException("Error al eliminar el producto", e);
        }
    }
}
