package com.mysql.conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

    // Configuración de la base de datos
    private static final String URL = "jdbc:mysql://localhost:3306/proyecto"; // Cambia 'proyecto' por tu base de datos
    private static final String USER = "root"; // Cambia 'root' por tu usuario de la base de datos
    private static final String PASSWORD = ""; // Cambia por tu contraseña de la base de datos

    static {
        try {
            // Cargar el driver JDBC de MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("Error al cargar el driver JDBC de MySQL", e);
        }
    }

    // Método para obtener la conexión
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}