package com.mysql.conexion;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

// Define el endpoint del servlet
@WebServlet("/InsertarEmpleado")
public class MainApp extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        // Recibir los datos del formulario
        String nombreEmpleado = request.getParameter("nombreEmpleado");
        String email = request.getParameter("email");
        String contraseña = request.getParameter("contraseña");

        // Conexión e inserción de datos
        try (Connection con = Conexion.getConnection();
             PrintWriter out = response.getWriter()) {

            // Consulta SQL para insertar datos
            String sql = "INSERT INTO empleado (NombreEmpleado, Email, Contraseña) VALUES (?, ?, ?)";
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, nombreEmpleado);
                ps.setString(2, email);
                ps.setString(3, contraseña);

                int rowsInserted = ps.executeUpdate();
                if (rowsInserted > 0) {
                    out.println("<h1>Empleado insertado exitosamente</h1>");
                } else {
                    out.println("<h1>Error al insertar el empleado</h1>");
                }
            }
        } catch (SQLException e) {
            throw new ServletException("Error SQL al insertar los datos", e);
        }
    }
}