package com.proyectoweb.servlets;

import com.mysql.conexion.Conexion;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Validar usuario en la base de datos
        boolean autenticado = false;
        String nombreEmpleado = null;
        String roles = null;

        try (Connection conn = Conexion.getConnection()) {
            String query = "SELECT NombreEmpleado, roles FROM empleado WHERE Email = ? AND Contrasena = ?";
            try (PreparedStatement ps = conn.prepareStatement(query)) {
                ps.setString(1, email);
                ps.setString(2, password);

                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        autenticado = true;
                        nombreEmpleado = rs.getString("NombreEmpleado");
                        roles = rs.getString("roles"); // Obtener el rol del usuario
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("mensaje", "Error al conectar con la base de datos.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
            return;
        }

        if (autenticado) {
            // Iniciar sesión y almacenar el nombre y el rol del usuario
            HttpSession session = request.getSession();
            session.setAttribute("usuarioLogeado", nombreEmpleado);
            session.setAttribute("rolUsuario", roles); // Guardar el rol en la sesión

            // Redirigir al inicio
            response.sendRedirect("index.jsp");
        } else {
            // Si falla la autenticación
            request.setAttribute("mensaje", "Usuario o contraseña incorrectos.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}