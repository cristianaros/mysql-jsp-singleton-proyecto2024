package com.proyectoweb.servlets;


import com.mysql.conexion.Conexion;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/RegistrarEmpleado")
public class RegistrarEmpleadoServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtener los datos del formulario
        String nombreEmpleado = request.getParameter("nombreEmpleado");
        String emailEmpleado = request.getParameter("emailEmpleado");
        String contrasena = request.getParameter("contrasena");

        // Validar los datos recibidos
        if (nombreEmpleado == null || nombreEmpleado.isEmpty() ||
            emailEmpleado == null || emailEmpleado.isEmpty() ||
            contrasena == null || contrasena.isEmpty()) {
            // Si hay algún error, redirigir al formulario con un mensaje
            request.setAttribute("mensaje", "Error: Todos los campos son obligatorios.");
            request.getRequestDispatcher("registrarEmpleado.jsp").forward(request, response);
            return;
        }

        // Insertar los datos en la base de datos
        boolean registroExitoso = false;
        try (Connection conn = Conexion.getConnection()) {
            String query = "INSERT INTO empleado (NombreEmpleado, Email, Contrasena) VALUES (?, ?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(query)) {
                ps.setString(1, nombreEmpleado);
                ps.setString(2, emailEmpleado);
                ps.setString(3, contrasena);

                registroExitoso = ps.executeUpdate() > 0; // Devuelve true si se insertaron registros
            }
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("mensaje", "Error al registrar el empleado: " + e.getMessage());
            request.getRequestDispatcher("registrarEmpleado.jsp").forward(request, response);
            return;
        }

        // Si el registro fue exitoso, establecer la sesión y redirigir al index.jsp
        if (registroExitoso) {
            HttpSession session = request.getSession();
            session.setAttribute("usuarioLogeado", nombreEmpleado); // Guarda el nombre del usuario en la sesión
            response.sendRedirect("index.jsp"); // Redirige al inicio
        } else {
            // Si hubo un error inesperado, redirigir con un mensaje de error
            request.setAttribute("mensaje", "Error al registrar el empleado. Inténtalo nuevamente.");
            request.getRequestDispatcher("registrarEmpleado.jsp").forward(request, response);
        }
    }
}