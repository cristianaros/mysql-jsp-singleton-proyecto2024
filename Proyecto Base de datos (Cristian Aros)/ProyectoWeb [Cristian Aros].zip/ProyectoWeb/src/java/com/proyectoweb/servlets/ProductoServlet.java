package com.proyectoweb.servlets;

import com.proyectoweb.servlets.Producto;
import com.mysql.conexion.Conexion;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/ProductoServlet")
public class ProductoServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Producto> productos = new ArrayList<>();

        try (Connection conn = Conexion.getConnection()) {
            String query = "SELECT * FROM producto";
            try (PreparedStatement ps = conn.prepareStatement(query); ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Producto producto = new Producto();
                    producto.setIdProducto(rs.getInt("idProducto"));
                    producto.setNombreProducto(rs.getString("NombreProducto"));
                    producto.setDescripcion(rs.getString("Descripcion"));
                    producto.setPrecio(rs.getDouble("Precio"));
                    producto.setStock(rs.getInt("Stock"));
                    productos.add(producto);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        System.out.println("Productos enviados al JSP:");
        for (Producto producto : productos) {
            System.out.println("Producto: " + producto.getNombreProducto());
        }

        request.setAttribute("productos", productos);
        request.getRequestDispatcher("index.jsp").forward(request, response);
    }
}